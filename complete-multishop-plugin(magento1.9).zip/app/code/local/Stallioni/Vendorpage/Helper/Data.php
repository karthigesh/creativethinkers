<?php
class Stallioni_Vendorpage_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 
